(function(){
  var Rusnometr, servers, allServers, processMessage, attemptConnection;
  window.Rusnometr = Rusnometr = (function(){
    Rusnometr.displayName = 'Rusnometr';
    var prototype = Rusnometr.prototype, constructor = Rusnometr;
    prototype.stiffness = 0.07;
    prototype.handDelay = 10;
    prototype.scale = 135;
    prototype.wiggleIntensity = 1 / 50;
    prototype.wiggleBaseRange = 0.05;
    prototype.maxDifference = 9;
    function Rusnometr($container){
      this.$container = $container;
      this.$handDel = this.$container.find('.rucicka');
      this.$inFavor = this.$container.find('.pro .value');
      this.$against = this.$container.find('.proti .value');
      this.$inBuilding = this.$container.find('.celkem .value');
      this.$remaining = this.$container.find('.zbyva .value');
      this.$percentage = this.$container.find('.procenta .value');
      this.$voteAccumulator = this.$container.find('.hlasAccumulator');
      this.targetValue = 0;
      this.currentValue = 0;
      this.forceQueue = new Array(this.handDelay);
      this.increment = 0;
      this.wiggle = 0;
      this.resultUncertainty = 1;
    }
    prototype.setValues = function(votesInFavor, votesAgainst, votesAbstained, inBuilding, lastVoteName, lastVodeType){
      var lastVoteTypeString, percentage, remaining, difference;
      lastVoteTypeString = (function(){
        switch (lastVodeType) {
        case 1:
          return "pro";
        case -1:
          return "proti návrhu";
        case 0:
          return "zdržel(a) se";
        default:
          return null;
        }
      }());
      percentage = votesInFavor / (votesInFavor + votesAgainst);
      remaining = inBuilding - votesInFavor - votesAgainst - votesAbstained;
      this.resultUncertainty = remaining / inBuilding;
      difference = votesInFavor - votesAgainst;
      if (difference > this.maxDifference) {
        difference = this.maxDifference;
      } else if (difference < this.maxDifference * -1) {
        difference = this.maxDifference * -1;
      }
      this.targetValue = difference / this.maxDifference;
      this.$percentage.html(Math.round(percentage * 100));
      this.$inFavor.html(votesInFavor);
      this.$against.html(votesAgainst);
      this.$inBuilding.html(inBuilding);
      this.$remaining.html(remaining);
      if (!lastVoteTypeString) {
        return;
      }
      return $("<div class='hlas'>Poslední hlas: <span class='name'>" + lastVoteName + "</span> &ndash; <span class='dir'>" + lastVoteTypeString + "</span></div>").prependTo(this.$voteAccumulator);
    };
    prototype.redraw = function(time){
      var timeDifference, steps, i$, x$, ref$, len$, index, difference, force, currentChange, degrees;
      if (!this.lastAnimationFrameTime) {
        this.lastAnimationFrameTime = time;
      }
      timeDifference = time - this.lastAnimationFrameTime;
      this.lastAnimationFrameTime = time;
      steps = Math.min(Math.round(timeDifference / 15), this.handDelay);
      for (i$ = 0, len$ = (ref$ = (fn$())).length; i$ < len$; ++i$) {
        x$ = ref$[i$];
        index = this.increment % this.handDelay;
        this.recomputeWiggle();
        difference = this.targetValue - this.currentValue;
        if (this.resultUncertainty > 0) {
          difference += this.wiggle;
        }
        force = difference * this.stiffness;
        this.forceQueue[index] = force;
        ++this.increment;
      }
      currentChange = this.forceQueue[index] || 0;
      this.currentValue += currentChange;
      if (currentChange) {
        degrees = this.toDegrees(this.currentValue);
        this.$handDel.css({
          transform: "rotate(" + degrees + "deg)",
          WebkitTransform: "rotate(" + degrees + "deg)",
          MsTransform: "rotate(" + degrees + "deg)",
          MozTransform: "rotate(" + degrees + "deg)",
          OTransform: "rotate(" + degrees + "deg)"
        });
      }
      return requestAnimationFrame(bind$(rusnometr, 'redraw'));
      function fn$(){
        var i$, to$, results$ = [];
        for (i$ = 0, to$ = steps; i$ <= to$; ++i$) {
          results$.push(i$);
        }
        return results$;
      }
    };
    prototype.toDegrees = function(value){
      return (this.scale / 2 * value) * -1;
    };
    prototype.recomputeWiggle = function(){
      var wiggleRange, wiggleOffset;
      wiggleRange = this.wiggleBaseRange * this.resultUncertainty;
      wiggleOffset = (function(){
        switch (false) {
        case !(this.wiggle > wiggleRange * 2):
          return 0.65;
        case !(this.wiggle > wiggleRange * 1):
          return 0.8;
        case !(this.wiggle < wiggleRange * -2):
          return 0.35;
        case !(this.wiggle < wiggleRange * -1):
          return 0.2;
        default:
          return 0.5;
        }
      }.call(this));
      return this.wiggle += (Math.random() - wiggleOffset) * this.wiggleIntensity;
    };
    return Rusnometr;
  }());
  window.rusnometr = new Rusnometr($(".ampermetr"));
  servers = ['http://80.79.23.187', 'http://195.140.252.93'];
  allServers = servers.slice(0);
  requestAnimationFrame(bind$(rusnometr, 'redraw'));
  processMessage = function(data){
    var status;
    status = data.status;
    return bind$(rusnometr, 'setValues').apply(null, status);
  };
  attemptConnection = function(){
    var index, address, x$, socket;
    if (!servers.length) {
      servers = allServers.slice(0);
    }
    index = Math.min(Math.round(Math.random() * servers.length - 0.5), servers.length - 1);
    address = servers[index];
    x$ = socket = io.connect(address);
    x$.on('news', processMessage);
    x$.on('connect_failed', function(){
      servers.splice(index, 1);
      return attemptConnection();
    });
    x$.on('disconnect', function(){
      servers.splice(index, 1);
      return attemptConnection();
    });
    x$.on('error', function(){
      servers.splice(index, 1);
      return attemptConnection();
    });
    return x$;
  };
  attemptConnection();
  function bind$(obj, key, target){
    return function(){ return (target || obj)[key].apply(obj, arguments) };
  }
}).call(this);
